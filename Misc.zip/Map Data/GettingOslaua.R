library(tidyverse)
long_bes <- BES2024_W29_Panel_v29_1 %>%
  pivot_longer(
    cols = matches("W\\d+$"),  # all columns ending in W + number
    names_to = c(".value", "wave"),
    names_pattern = "(.*)W(\\d+)$"
  ) %>%
  mutate(wave = as.integer(wave))

names(BES2024_W29_Panel_v29_1)[str_detect(names(BES2024_W29_Panel_v29_1), "oslaua")]

oslaua_long <- BES2024_W29_Panel_v29_1 %>%
  select(id, matches("^oslauaW\\d+$")) %>%
  pivot_longer(
    cols = matches("^oslauaW\\d+$"),
    names_to = "wave",
    names_pattern = "oslauaW(\\d+)",
    values_to = "oslaua"
  ) %>%
  mutate(wave = as.integer(wave))
write_dta(oslaua_long, "oslaua_long.dta")